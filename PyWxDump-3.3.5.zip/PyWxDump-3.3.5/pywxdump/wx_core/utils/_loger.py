# -*- coding: utf-8 -*-#
# -------------------------------------------------------------------------------
# Name:         _loger.py
# Description:  
# Author:       xaoyaoo
# Date:         2024/07/23
# -------------------------------------------------------------------------------
import logging

wx_core_loger = logging.getLogger("wx_core")
