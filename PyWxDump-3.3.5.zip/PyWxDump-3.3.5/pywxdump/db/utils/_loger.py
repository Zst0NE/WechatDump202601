# -*- coding: utf-8 -*-#
# -------------------------------------------------------------------------------
# Name:         _loger.py
# Description:  
# Author:       xaoyaoo
# Date:         2024/07/23
# -------------------------------------------------------------------------------
import logging

db_loger = logging.getLogger("db_prepare")
