# -*- coding: utf-8 -*-#
# -------------------------------------------------------------------------------
# Name:         test_dbshow.py
# Description:  显示数据库聊天记录
# Author:       xaoyaoo
# Date:         2023/11/15
# -------------------------------------------------------------------------------

from pywxdump import start_server

merge_path = r"D:\****.db"

start_server(merge_path=merge_path)
